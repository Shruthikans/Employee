package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService implements EmployeeServiceInterface{
@Autowired
private EmployeeRepository employeeRepository;

@Override
public Employee addEmployee(Employee employee) {
	Employee savedEmployee=employeeRepository.save(employee);
	return savedEmployee;
	
	
	
}

@Override
public List<Employee> getAllEmployees() {
	
	return employeeRepository.findAll();
}

@Override
public Employee getEmpById(int empidL) {
	
	return employeeRepository.findById(empidL).get();
}

@Override
public void deleteEmpById(int empidL) {
    employeeRepository.deleteById(empidL);
}


}
